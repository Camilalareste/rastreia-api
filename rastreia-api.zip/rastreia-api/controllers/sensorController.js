// controllers/sensorController.js
async function getSensorData(req) { // Recebe req for consistency, but doesn't use it
  const data = {
    umidade: Math.floor(Math.random() * 100),
    ph: (Math.random() * (7.5 - 5.5) + 5.5).toFixed(2),
    temperatura: Math.floor(Math.random() * (35 - 18) + 18)
  };
  return data;
}

module.exports = { getSensorData };