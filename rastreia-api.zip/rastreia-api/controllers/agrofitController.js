// controllers/agrofitController.js
const axios = require('axios');

async function getProdutosFormulados(req) {
  try {
    const token = process.env.AGROAPI_TOKEN; // Certifique-se de ter essa variável no .env
    const response = await axios.get(
      'https://api.cnptia.embrapa.br/agrofit/v1/produtos-formulados',
      { headers: { Authorization: `Bearer ${token}` } }
    );
    return response.data;
  } catch (error) {
    console.error(error);
    throw new Error('Erro ao obter produtos formulados do Agrofit'); // Propaga o erro
  }
}

module.exports = { getProdutosFormulados };