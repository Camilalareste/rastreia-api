// controllers/satvegController.js
const axios = require('axios');

async function getVegetacao(req) {
  try {
    const { lat, lon, inicio, fim } = req.query;
    if (!lat || !lon || !inicio || !fim) {
      throw new Error('Informe lat, lon, inicio e fim');
    }

    const token = process.env.SATVEG_API_KEY; // Certifique-se de ter essa variável no .env

    const { data } = await axios.get(
      `https://api.cnptia.embrapa.br/satveg/v2/serie-temporal?lat=${lat}&lon=${lon}&inicio=${inicio}&fim=${fim}`,
      { headers: { Authorization: `Bearer ${token}` } }
    );

    return data;
  } catch (err) {
    console.error(err.message);
    throw new Error('Erro ao consultar SATVeg');
  }
}

module.exports = { getVegetacao };